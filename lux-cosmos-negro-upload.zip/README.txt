LUX — COSMOS NEGRO

Estrutura pronta para Cloudflare Pages.

1. Mantenha index.html, style.css, script.js e a pasta dados/ na raiz.
2. Coloque os MP3 exatamente nos caminhos indicados em audios/lux/cosmos-negro/.
3. Os controles <audio> apontam automaticamente para esses caminhos relativos.
4. Publique a pasta inteira no Cloudflare Pages.

Os arquivos MP3 não estão incluídos nesta estrutura porque os áudios da Lux não foram fornecidos nesta conversa.
